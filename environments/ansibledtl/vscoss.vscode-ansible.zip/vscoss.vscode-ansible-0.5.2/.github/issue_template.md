<!---
Verify first that your issue/request is not already reported on GitHub.
Also test if the latest release.
-->

## Environment
- Extension version: 
- OS Type: Windows/Linux/MacOS

## Summary
<!--Describe the issue briefly-->

## Reproduce steps
<!--steps to reproduce the issue-->


## Expected Results
<!--What did you expect to happen when running the steps above-->


## Actual Results
<!--What actually happened-->