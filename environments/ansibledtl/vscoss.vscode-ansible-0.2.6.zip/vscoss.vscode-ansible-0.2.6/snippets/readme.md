## how to generate code snippets
1. use <root>/scripts/parse_ansible.py to parse ansible document, generate ansible-data.json.
1. use <root>/scripts/generate_codesnippets.ts to generate code snippets based on module doc in ansible-data.json.